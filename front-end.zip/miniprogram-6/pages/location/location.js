Page({
  data: {
    markers: [], // 存储建筑物标记
    building: {} // 存储建筑物信息
  },

  onLoad(options) {
    const buildingId = options.id; // 获取传递的建筑物 ID

    // 请求建筑物数据
    wx.request({
      url: `http://10.37.74.222:5000/buildings/${buildingId}`, // 使用建筑物 ID 请求数据
      method: 'GET',
      success: (res) => {
        if (res.statusCode === 200) {
          this.setData({
            building: res.data // 设置建筑物信息
          });
          this.setMarkers(res.data); // 设置地图标记
        } else {
          console.error('请求失败', res);
        }
      },
      fail: (err) => {
        console.error('请求错误', err);
      }
    });
  },

  setMarkers(building) {
    const markers = [{
      id: building.id, // 使用建筑物 ID
      latitude: building.latitude,
      longitude: building.longitude,
      title: building.name,
      iconPath: "https://github.com/Evelyn6868/app/blob/main/marker.png?raw=true", // 自定义标记图标路径
      width: 30,
      height: 30
    }];

    // 设置 markers 数据
    this.setData({
      markers: markers
    });
  }
});
