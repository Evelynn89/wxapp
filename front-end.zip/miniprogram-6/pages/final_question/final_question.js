Page({
  data: {
    question: '',  // 最终问题
    choices: [],    // 最终问题的选项
    answer: '',     // 正确答案
    url: '',         // 图片URL
    choicePrefixes: ['A.', 'B.', 'C.'], // 选项前缀
    currentQueId: 1,  // 当前题目 ID（用于定位）
    buildingId: null, // 建筑物 ID
    allQuestions: [], // 所有问题
  },

  onLoad: function(options) {
    const buildingId = options.id;  // 获取建筑物 ID
    const queId = options.que_id;   // 获取当前题目 ID
    console.log('que:', queId);
    // 设置建筑物ID和当前题目ID
    this.setData({
      buildingId: buildingId,
      currentQueId: queId
    });

    // 获取所有题目数据
    this.fetchQuizData(buildingId);  // 获取所有问题数据
    this.fetchBuildingDetails(buildingId);  // 获取建筑物详情
  },

  // 获取建筑物详情
  fetchBuildingDetails: function(buildingId) {
    wx.request({
      url: `http://10.37.74.222:5000/buildings/${buildingId}`,  // 查询建筑物详细信息
      method: 'GET',
      success: (res) => {
        if (res.statusCode === 200) {
          const imageUrl = `http://10.37.74.222:5000${res.data.image_url1}`;
          this.setData({
            url: imageUrl  // 设置建筑物的图片
          });
        } else {
          console.error('请求失败', res);
        }
      },
      fail: (err) => {
        console.error('请求错误', err);
      }
    });
  },

  // 获取所有问题数据
  fetchQuizData: function(buildingId) {
    const that = this;
    wx.request({
      url: `http://10.37.74.222:5000/get_quiz?id=${buildingId}`,  // 获取所有问题数据
      method: 'GET',
      success(res) {
        console.log('Quiz data response:', res.data);
        const currentQueId = Number(that.data.currentQueId);
        console.log('Current QueId:', currentQueId);
        if (res.data && !res.data.error) {
          const allQuestions = res.data;
          console.log('allQuestions:', allQuestions);
          const currentQuestion = allQuestions.find(item => item.que_id === currentQueId);  // 根据 que_id 找到当前题目
          console.log('Questions:', currentQuestion);
          if (currentQuestion) {
            that.setData({
              allQuestions: allQuestions,  // 保存所有问题
              question: currentQuestion.question,
              choices: currentQuestion.choices,
              answer: currentQuestion.answer,
            });
          }
        } else {
          console.error("Failed to load quiz data:", res.data.error);
        }
      },
      fail(err) {
        console.error("Request failed:", err);
      }
    });
  },

  // 选择答案
  selectChoice: function(event) {
    const selectedChoice = event.currentTarget.dataset.choice;
    const isCorrect = selectedChoice === this.data.answer;

    this.setData({
      selectedChoice: selectedChoice,
      isCorrect: isCorrect
    });

    if (isCorrect) {
      wx.showToast({
        title: '回答正确!',
        icon: 'success'
      });
    } else {
      wx.showToast({
        title: '回答错误!',
        icon: 'error'
      });
    }
  },

  // 返回上一页
  goBack: function() {
    wx.navigateBack();
  }
});


