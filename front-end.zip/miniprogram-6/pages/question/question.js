Page({
  data: {
    question: '',  // 当前问题
    choices: [],    // 当前问题的选项
    answer: '',     // 正确答案
    url: '',         // 图片URL
    choicePrefixes: ['A.', 'B.', 'C.'], // 选项前缀
    currentQueId: 1,  // 当前题目 ID（用于定位）
    allQuestions: [], // 所有问题
    buildingId: null, // 建筑物 ID
  },

  onLoad: function(options) {
    const buildingId = options.id;  // 从 URL 参数中获取 buildingId
    const queId = options.que_id || 1;  // 默认从第一个问题开始
    this.setData({
      currentQueId: queId,  // 设置当前题目 ID
      buildingId: buildingId
    });
    this.fetchQuizData(buildingId, queId);  // 根据 buildingId 和 queId 获取数据
    this.fetchBuildingDetails(buildingId);  // 获取建筑物详情
  },

  // 获取建筑物详情
  fetchBuildingDetails: function(buildingId) {
    wx.request({
      url: `http://10.37.74.222:5000/buildings/${buildingId}`,  // 查询建筑物详细信息
      method: 'GET',
      success: (res) => {
        if (res.statusCode === 200) {
          const imageUrl = `http://10.37.74.222:5000${res.data.image_url1}`;
          this.setData({
            url: imageUrl  // 设置建筑物的图片
          });
        } else {
          console.error('请求失败', res);
        }
      },
      fail: (err) => {
        console.error('请求错误', err);
      }
    });
  },

  // 获取问题数据
  fetchQuizData: function(buildingId, queId) {
    const that = this;
    wx.request({
      url: `http://10.37.74.222:5000/get_quiz?id=${buildingId}`,  // 获取所有问题数据
      method: 'GET',
      success(res) {
        console.log('Quiz data response:', res.data);
        if (res.data && !res.data.error) {
          // 获取所有问题
          const allQuestions = res.data;
          const currentQuestion = allQuestions.find(item => item.que_id === queId);  // 根据 que_id 找到当前题目
          
          if (currentQuestion) {
            that.setData({
              allQuestions: allQuestions,
              question: currentQuestion.question,
              choices: currentQuestion.choices,
              answer: currentQuestion.answer,
            });
          }
        } else {
          console.error("Failed to load quiz data:", res.data.error);
        }
      },
      fail(err) {
        console.error("Request failed:", err);
      }
    });
  },

  // 选择答案
  selectChoice: function(event) {
    const selectedChoice = event.currentTarget.dataset.choice;
    const isCorrect = selectedChoice === this.data.answer;

    this.setData({
      selectedChoice: selectedChoice,
      isCorrect: isCorrect
    });

    if (isCorrect) {
      wx.showToast({
        title: '回答正确!',
        icon: 'success'
      });
    } else {
      wx.showToast({
        title: '回答错误!',
        icon: 'error'
      });
    }
  },

  // 跳转到下一题
  nextQuestion: function() {
    const { currentQueId, buildingId, allQuestions } = this.data;
    const nextQueId = currentQueId + 1;  // 下一题 ID
    console.log('All:', allQuestions);
    console.log('hh:', nextQueId);
    // 通过 nextQueId 来找到下一题
    const nextQuestion = allQuestions.find(item => item.que_id === nextQueId);
    console.log('nextQuestion:', nextQuestion);  // 打印 nextQuestion
    if (nextQuestion) {
      // 如果找到下一题，则跳转
      wx.navigateTo({
        url: `/pages/final_question/final_question?id=${buildingId}&que_id=${nextQueId}`,
        success: () => {
          // 成功跳转时后台打印日志
          console.log('Successfully navigated to next question!');
        },
        fail: (err) => {
          console.error('Failed to navigate to next question:', err);
        }
      });
    } else {
      wx.showToast({
        title: '已是最后一题',
        icon: 'none'
      });
    }
  },

  // 返回上一页
  goBack: function() {
    wx.navigateBack();
  }
});

