Page({
  data: {
    neighbors: [], // 存储邻近建筑的数据
    randomBuildings: [] // 存储随机推荐的建筑数据
  },

  onLoad: function (options) {
    const buildingId = options.id; // 获取从上一页面传递过来的建筑物 ID
    this.fetchNeighborDetails(buildingId);
    this.fetchRandomBuildings(buildingId);
  },

  // 获取邻近建筑数据
  fetchNeighborDetails: function (id) {
    wx.request({
      url: `http://10.37.74.222:5000/neighbors/${id}`, // 调用后端接口获取邻近建筑信息
      method: 'GET',
      success: (res) => {
        if (res.statusCode === 200) {
          // 拼接完整的图片 URL
          const ipAddress = 'http://10.37.74.222:5000'; // 使用你的 IP 地址
          const neighbors = res.data.map(neighbor => {
            return {
              ...neighbor,
              image_url: `${ipAddress}${neighbor.image_url}` // 拼接完整的图片 URL
            };
          });

          this.setData({
            neighbors: neighbors
          });
        } else {
          console.error('请求失败', res);
        }
      },
      fail: (err) => {
        console.error('请求错误', err);
      }
    });
  },

  // 获取随机推荐的建筑数据，排除邻近的建筑
  fetchRandomBuildings: function (currentBuildingId) {
    wx.request({
      url: 'http://10.37.74.222:5000/random_buildings', // 调用后端接口获取随机建筑信息
      method: 'GET',
      success: (res) => {
        if (res.statusCode === 200) {
          // 拼接完整的图片 URL
          const ipAddress = 'http://10.37.74.222:5000'; // 使用你的 IP 地址
          const randomBuildings = res.data.filter(building => building.id !== currentBuildingId).map(building => {
            return {
              ...building,
              image_url: `${ipAddress}${building.image_url}` // 拼接完整的图片 URL
            };
          });

          this.setData({
            randomBuildings: randomBuildings
          });
        } else {
          console.error('请求失败', res);
        }
      },
      fail: (err) => {
        console.error('请求错误', err);
      }
    });
  },

  // 跳转到建筑物的详情页面
  goToIntroduction: function (event) {
    const buildingId = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/introduction/introduction?id=${buildingId}`
    });
  }
});

