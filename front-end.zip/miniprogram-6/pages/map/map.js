Page({
  data: {
    markers: [],                // 存储建筑物标记
    currentName: "",            // 当前选中的建筑物名称
    currentAddress: "",         // 当前选中的建筑物地址
    showDescriptionBox: false,  // 描述框是否显示
    mapScale: 14,               // 地图缩放级别
    imageSrc: "",               // 图片路径
    idMap: {}                   // 映射关系：marker index -> 数据库中的建筑物 id
  },

  onLoad(options) {
    const that = this;
    const targetBuildingId = options.id; // 获取传递过来的建筑物 ID（如果有）

    wx.request({
      url: 'http://10.37.74.222:5000/buildings',   // 使用局域网 IP 或 ngrok 生成的公网 URL
      method: 'GET',
      success: function(res) {
        const buildings = res.data;

        // 构造 markers 并创建 id 映射
        const markers = buildings.map((building, index) => {
          that.data.idMap[index] = building.id; // 将数据库中的建筑物 id 关联到 marker 的 index
          return {
            id: index,  // 使用 index 作为 marker 的 id，确保是数值类型
            latitude: building.latitude,
            longitude: building.longitude,
            title: building.name,
            address: building.address,
            image_url: building.image_url,  // 添加图片 URL
            iconPath: "/static/marker.png",
            width: 30,
            height: 40
          };
        });

        that.setData({
          markers: markers
        }, () => {
          // 如果有目标建筑物 ID，则自动执行点击逻辑
          if (targetBuildingId) {
            const markerIndex = Object.keys(that.data.idMap).find(
              key => that.data.idMap[key] === parseInt(targetBuildingId)
            );

            if (markerIndex !== undefined) {
              that.onMarkerTap({ markerId: parseInt(markerIndex) });
            }
          }
        });
      },
      fail: function(err) {
        console.error("API 请求失败：", err);
      }
    });

    // 初始化 mapCtx
    this.mapCtx = wx.createMapContext('map');
  },

  // 点击 marker 时，更新描述框内容、图片路径，并放大地图
  onMarkerTap(event) {
    const markerId = event.markerId;  // 这是点击时返回的 marker 的 index

    // 根据 index 找到对应的建筑物 id
    const buildingId = this.data.idMap[markerId];
    if (buildingId === undefined) {
      console.error("未找到对应的 buildingId");
      return;
    }

    const marker = this.data.markers.find(m => m.id === markerId);

    if (marker) {
      const baseUrl = 'http://10.37.74.222:5000';  // 服务器的基础 URL

      this.setData({
        currentName: marker.title,
        currentAddress: marker.address,
        showDescriptionBox: true,               // 显示描述框
        mapScale: 18,                           // 放大地图级别
        imageSrc: `${baseUrl}${marker.image_url}`  // 拼接完整的图片 URL
      }, () => {
        // 确保地图数据更新后再移动和缩放
        this.mapCtx.moveToLocation({
          latitude: marker.latitude,
          longitude: marker.longitude
        });

        // 更新地图缩放级别
        this.mapCtx.getCenterLocation({
          success: () => {
            this.mapCtx.includePoints({
              points: [{
                latitude: marker.latitude,
                longitude: marker.longitude
              }],
              padding: [80, 50, 30, 50]  // 为了确保描述框不会覆盖 marker，适当加些 padding
            });
          }
        });
      });
    }
  },

  onGoNowTap() {
    const { currentName, markers } = this.data;
    const marker = markers.find(m => m.title === currentName);
  
    if (marker) {
      wx.getLocation({
        type: 'gcj02',  // 高德地图使用 GCJ-02 坐标
        success: (location) => {
          const startLatitude = location.latitude;
          const startLongitude = location.longitude;
          const endLatitude = marker.latitude;
          const endLongitude = marker.longitude;
  
          // 使用 wx.openLocation 直接在微信中唤起地图导航
          wx.openLocation({
            latitude: endLatitude,
            longitude: endLongitude,
            name: currentName,
            address: this.data.currentAddress,
            scale: 18
          });
        },
        fail: function (err) {
          console.error("获取位置失败", err);
        }
      });
    }
  },
  

  onShareAppMessage() {
    return {};
  }
});
