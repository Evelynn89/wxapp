// index.js
Page({
  data: {},

  onShareAppMessage() {
    return {};
  },
  takePhoto() {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['camera', 'album'],
      success: (res) => {
        const tempFilePath = res.tempFilePaths[0];
        console.log('照片路径:', tempFilePath);

        wx.uploadFile({
          url: 'http://10.37.74.222:5000/upload_photo',
          filePath: tempFilePath,
          name: 'photo',
          success: (uploadRes) => {
            console.log('上传成功:', uploadRes);

            try {
              const data = JSON.parse(uploadRes.data);
              if (uploadRes.statusCode === 200) {
                console.log('检测结果:', data.detections);
                wx.showToast({
                  title: '检测成功',
                  icon: 'success'
                });

                if (data.detections && data.detections.length > 0) {
                  // 如果检测到多个建筑物，则让用户选择要查看的建筑物
                  const buildingOptions = data.detections.map((detection, index) => {
                    const buildingInfo = detection.building_info;
                    return `建筑物 ${index + 1} - ${buildingInfo ? buildingInfo.name : '未知名称'} - 置信度: ${Math.round(detection.confidence * 100)}%`;
                  });

                  wx.showActionSheet({
                    itemList: buildingOptions,
                    success: (res) => {
                      const selectedIndex = res.tapIndex;
                      const selectedBuildingId = data.detections[selectedIndex].building_info.id;
                      console.log(`用户选择查看的建筑物ID: ${selectedBuildingId}`);

                      wx.navigateTo({
                        url: `/pages/introduction/introduction?id=${selectedBuildingId}`
                      });
                    },
                    fail: (err) => {
                      console.error('用户取消选择', err);
                    }
                  });
                } else {
                  console.error('没有检测到任何建筑物');
                  wx.showToast({
                    title: '未识别建筑',
                    icon: 'none'
                  });
                }
              } else {
                console.error('上传失败，状态码:', uploadRes.statusCode);
                wx.showToast({
                  title: '检测失败',
                  icon: 'error'
                });
              }
            } catch (e) {
              console.error('JSON 解析失败:', e);
              wx.showToast({
                title: '检测失败，服务器响应无效',
                icon: 'error'
              });
            }
          },
          fail: (err) => {
            console.error('上传失败', err);
            wx.showToast({
              title: '上传失败',
              icon: 'error'
            });
          }
        });
      },
      fail: (err) => {
        console.error('选择照片失败', err);
      }
    });
  },
  
  
  // 添加的页面跳转方法
  navigateToList() {
    wx.navigateTo({
      url: '/pages/archilist/archilist', // 跳转到 pages/list/list 页面
      success: () => {
        console.log('跳转到建筑列表页面成功');
      },
      fail: (err) => {
        console.error('跳转到建筑列表页面失败', err);
      }
    });
  }
});